go mod init demo
go mod tidy
go build
